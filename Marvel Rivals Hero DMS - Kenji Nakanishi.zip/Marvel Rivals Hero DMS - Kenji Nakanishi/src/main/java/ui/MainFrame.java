/*
Professor: Lisa Macon
Name: Kenji Nakanishi
Course: CEN 3024C - Software Development-I CRN:14877
Date: 10/30/2025

Purpose of the DMS in this phase: After added the logic and confirmed all the test has been successful.
Now, we must add the GUI, taking care of the previous classes and using same logic.
The GUI was inspired on Marvel Rivals Colours, and whenever user hoverover the buttons it
changes the color, functionalities such as add, remove, update, and display has been checked.
and the custom method which is Win Rate report is created where the user specified to.

Phase 3: Adding a UI  || Graphic User Interface
 */

package ui;

import main.FileHeroRepository;
import main.Hero;
import main.HeroFunctionalities;
import com.formdev.flatlaf.FlatDarkLaf;
import javax.swing.*;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.event.*;
import java.awt.*;
import java.net.URL;
import java.nio.file.Path;
import java.util.List;

public class MainFrame extends JFrame {
    // Used MainFrame to arrange and organize visualization structure
    // later code specific demand of the requirements.
    private JPanel mainPanel;
    private JPanel leftPanel;
    private JPanel rightPanel;
    private JButton btnAddHero;
    private JButton btnUpdateHero;
    private JButton btnRemoveHero;
    private JButton btnImport;
    private JButton btnGeneratePDF;
    private JButton btnExit;
    private JTable heroTable;
    private final DefaultTableModel heroModel;
    private final HeroFunctionalities heroFunctionalities;

    private final FileHeroRepository repo = new FileHeroRepository();
    private boolean dirty = false;
    // Created a GradientButtonUI for making hoverover colour change possible.
    // This calls the design that will be used
    private void skinButton(AbstractButton b) {
        b.setUI(new GradientButtonUI());
    }
    @SuppressWarnings("SameParameterValue")
    private static ImageIcon safeIcon(String path){
        URL url = MainFrame.class.getResource(path);
        return (url != null) ? new ImageIcon(url) : null;
    }

    public MainFrame() {
        FlatDarkLaf.setup();
        // I wanted to have the Marvel Rivals logo both on Icon and as a image on the top left of the application.
        ImageIcon appIcon = safeIcon("/MR_Logo.png");
        if(appIcon != null) {
            setIconImage(appIcon.getImage());
        }

        //Table side colours and organization
        UIManager.put("Component.arc", 12);
        UIManager.put("Button.arc", 16);
        UIManager.put("Table.showHorizontalLines", true);
        UIManager.put("Table.showVerticalLines", false);
        UIManager.put("Component.focusColor", Color.decode("#00B0FF"));
        UIManager.put("Button.startBackground", Color.decode("#D91A2A"));
        UIManager.put("Button.endBackground",   Color.decode("#D91A2A"));
        UIManager.put("Button.foreground", Color.WHITE);

        // Gaming Marvel Rivals colours for buttons
        Color MR_RED    = new Color(0xE2,0x36,0x36); // #e23636
        Color MR_GRAY   = new Color(0x50,0x4A,0x4A); // #504a4a
        Color MR_BLUE   = new Color(0x51,0x8C,0xCA); // #518cca

        UIManager.put("Component.focusColor", MR_BLUE);
        UIManager.put("Button.startBackground", MR_RED);
        UIManager.put("Button.endBackground",   MR_RED);
        UIManager.put("Button.foreground", Color.WHITE);

        UIManager.put("Table.selectionBackground", MR_BLUE);
        UIManager.put("Table.selectionForeground", Color.WHITE);
        UIManager.put("Table.gridColor", MR_GRAY);
        UIManager.put("Panel.background", new Color(32,32,32));   // nicer dark bg
        UIManager.put("Label.foreground", Color.WHITE);

        setTitle("Marvel Rivals Hero DMS");
        setContentPane(mainPanel);

        // icon picture; small but can be used for user reference and also as left side picture
        ImageIcon rawIcon = safeIcon("/MR_Logo.png");
        if (rawIcon != null) {
            Image scaled = rawIcon.getImage().getScaledInstance(200, 100, Image.SCALE_SMOOTH);
            JLabel logoLabel = new JLabel(new ImageIcon(scaled));
            logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
            logoLabel.setVerticalAlignment(SwingConstants.CENTER);
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            logoLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

            leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
            leftPanel.add(logoLabel);
            leftPanel.add(Box.createVerticalStrut(10));
        } else {
            leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
            leftPanel.add(Box.createVerticalStrut(10));
        }

        // giving the buttons some space for better look
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(btnAddHero);
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(btnUpdateHero);
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(btnRemoveHero);
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(btnImport);
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(btnGeneratePDF);
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(btnExit);
        leftPanel.add(Box.createVerticalGlue());


        // the app size when hitting on run
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(1200, 600);
        setLocationRelativeTo(null);

        skinButton(btnAddHero);
        skinButton(btnUpdateHero);
        skinButton(btnRemoveHero);
        skinButton(btnImport);
        skinButton(btnGeneratePDF);
        skinButton(btnExit);

        for (Component comp : leftPanel.getComponents()) {
            if (comp instanceof JButton btn) {
                btn.setAlignmentX(Component.CENTER_ALIGNMENT);
                btn.setMaximumSize(new Dimension(200,50));
            }
        }
        // This class contains the logic for each of the CRUD methods
        // when adding the inMemoryHeroRepositoy it will be storing them
        heroFunctionalities = new main.HeroFunctionalities(new main.InMemoryHeroRepository());

        String[] cols = {
                "Hero ID", "Name", "HP", "Movement Speed", "Ult Damage", "Role", "Win Rate"
        };
        heroModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) {   return false; }
            @Override public Class<?> getColumnClass(int col) {
                return switch (col) {
                    // Health Point, Movement Speed, and Ult Damage
                    case 2, 3, 4 -> Integer.class;
                    // Win Rate
                    case 6 -> Double.class;
                    // Hero ID, Name, and Role
                    default -> String.class;
                };
            }
        };

        //This specifies the design od the table that will be displayed to the user
        heroTable.setModel(heroModel);
        heroTable.setAutoCreateRowSorter(true);
        heroTable.setRowHeight(22);
        heroTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        heroTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        heroTable.setRowSorter(new TableRowSorter<>(heroModel));
        // notice is very important to have a ScrollPane
        rightPanel.setLayout(new BorderLayout());
        rightPanel.removeAll();
        rightPanel.add(new JScrollPane(heroTable), BorderLayout.CENTER);


        // Added a Menu item section, not needed but nice to have it as well!
        // it performs same logic as when clicking save, it will prompt to save it
        // the only difference is the Exit which will exit straighforward not like the button which
        // will prompt to save before exit
        JMenuBar mb = new JMenuBar();
        JMenu file = new JMenu("File");
        JMenuItem open = new JMenuItem("Open");
        JMenuItem save = new JMenuItem("Save");
        JMenuItem saveAs = new JMenuItem("Save As");
        JMenuItem exit = new JMenuItem("Exit");

        save.setAccelerator(KeyStroke.getKeyStroke("control S"));
        open.addActionListener(e -> doOpen());
        save.addActionListener(e -> doSave(false));
        saveAs.addActionListener(e->doSave(true));
        exit.addActionListener(e -> doExit());
        file.add(open); file.add(save); file.add(saveAs); file.addSeparator(); file.add(exit);
        mb.add(file);
        setJMenuBar(mb);

        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { doExit(); }
        });


        //the ActionListener are been set to detect an event in this case called e and track
        // whenever the user has some changes in the program with the dirty
        // * we can detect by seeing the asterisk symbol ** and then the program will know the status of dirty
        btnAddHero.addActionListener(e -> {addHero(); dirty = true; updateTitle(); });
        btnUpdateHero.addActionListener(e -> {updateHero(); dirty = true; updateTitle(); });
        btnRemoveHero.addActionListener(e -> {removeHero(); dirty = true; updateTitle(); });
        btnImport.addActionListener(e -> { importHeroes(); dirty = true; updateTitle(); });
        btnGeneratePDF.addActionListener(e -> generateReport());
        btnExit.addActionListener(e -> doExit());

        refreshTable();
        updateTitle();
        setVisible(true);
    }


    // Previously mentioned * comparison to let the user know when unsaved status is
    private void updateTitle() {
        String star = dirty ? " *" : "";
        String fileName = repo.getCurrentFile().map(Path::getFileName).map(Object::toString).orElse("Untitled");
        setTitle(fileName + star + " - Marvel Rivals Hero DMS");
    }
    //This will show all the updated information on the GUI
    // since we have the CRUD methods, we need to perfom a refresh table after
    // each operation!
    private void refreshTable() {
        heroModel.setRowCount(0);
        List<Hero> heroes = heroFunctionalities.listHeroes();
        for (Hero h : heroes) {
            heroModel.addRow(new Object[]{
                    h.getIdentityHeroID(),
                    h.getHeroName(),
                    h.getHealthPoint(),
                    h.getMovementSpeed(),
                    h.getUltDamage(),
                    h.getHeroRole(),
                    h.getWinRate()
            });
        }
    }
    private void toast(String msg) {
        JOptionPane.showMessageDialog(this, msg);
    }
    //Basically perform the add of the hero as previously explained logic
    private void addHero() {
        HeroForm form = new HeroForm(this, null);
        Hero hero = form.showDialog();
        if (hero == null) return;

        for (int i = 0; i < heroModel.getRowCount(); i++) {
            if (String.valueOf(heroModel.getValueAt(i,0)).equals(hero.getIdentityHeroID())) {
                toast("Duplicate Hero ID:" + hero.getIdentityHeroID());
                return;
            }
        }
        boolean ok = heroFunctionalities.addHero(hero);
        if (!ok)  { toast("Something went wrong!! Add failed..."); return; }
        refreshTable();
    }
    private void updateHero() {
        int vr = heroTable.getSelectedRow();
        if (vr < 0) {
            toast("Selected a Marvel Rivals Hero in the table to UPDATE.");
            return;
        }
        Hero current = rowToHero(vr);
        HeroForm form = new HeroForm(this, current);
        Hero edited = form.showDialog();
        if (edited == null) return;
        if (!edited.getIdentityHeroID().equals(current.getIdentityHeroID())) {
            for (int i = 0; i < heroModel.getRowCount(); i++) {
                if (String.valueOf(heroModel.getValueAt(i, 0)).equals(edited.getIdentityHeroID())) {
                    toast("Existing ID: Another row already uses ID!!! " + edited.getIdentityHeroID());
                    return;
                }
            }
        }
        try {
            boolean ok = heroFunctionalities.updateMarvelHero(edited);
            if (!ok) {
                heroFunctionalities.removeMarvelHeroById(current.getIdentityHeroID());
                ok = heroFunctionalities.addHero(edited);
            }
            if (!ok) {
                toast("Something went wrong! Update failed....");
                return;
            }
                refreshTable();
                dirty = true;
                updateTitle();
            } catch(IllegalArgumentException ex){
                toast("Invalid data: " + ex.getMessage());
            } catch(Exception ex){
                toast("Error! " + ex.getMessage());
            }
        }
    private void removeHero() {
        int viewRow = heroTable.getSelectedRow();
        if (viewRow < 0) {
            toast("Select a Marvel Rivals Hero to REMOVE.");
            return;
        }
        int modelRow = heroTable.convertRowIndexToModel(viewRow);
        String id = String.valueOf(heroModel.getValueAt(modelRow, 0));
        int ok = JOptionPane.showConfirmDialog(
                this,
                "Remove hero " + id + "?",
                "Confirm",
                JOptionPane.YES_NO_OPTION
        );

        if (ok != JOptionPane.YES_OPTION) return;

        boolean removed = heroFunctionalities.removeMarvelHeroById(id);
        if (!removed) {
            toast("Something went wrong! Remove failed...");
            return;
        }
        refreshTable();
        dirty = true;
        updateTitle();
    }


    private void importHeroes() {
        JFileChooser fc = new JFileChooser();
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;

        Path path = fc.getSelectedFile().toPath();
        try {
            HeroFunctionalities.ImportResult r = heroFunctionalities.loadFromSavedFile(path);
            repo.setCurrentFile(path);
            refreshTable();
            toast(r.toString());
        } catch (Exception ex) {
            toast("Something went wrong! Import failed... " + ex.getMessage());
        }
    }
    private void generateReport() {
        try {
            JFileChooser fc = new JFileChooser();
            fc.setDialogTitle("Save Win Rate report");
            if(fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

            Path out = fc.getSelectedFile().toPath();
            String name = out.getFileName().toString().toLowerCase();
            if (!name.endsWith(".pdf")) {
                out = out.resolveSibling(out.getFileName() + ".pdf");
            }
            heroFunctionalities.generateWinRateReport(out);
            try {Desktop.getDesktop().open(out.toFile()); } catch (Exception ignore) {}
            toast("PDF has been saved to:\n" + out.toAbsolutePath());
        } catch (Exception ex) {
            toast("Someting went wrong. Generate report failed... " + ex.getMessage());
        }
    }


    // now we have some methods for file management
    // doOpen can handle csv and txt files to the table
    private void doOpen() {
        JFileChooser fc = new JFileChooser();
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;

        Path path = fc.getSelectedFile().toPath();
        try{
            HeroFunctionalities.ImportResult r = heroFunctionalities.loadFromSavedFile(path);

            repo.setCurrentFile(path);
            refreshTable();
            dirty = false;
            updateTitle();
            toast("Opened: " + path.getFileName() + "\n" + r.toString());
        } catch (Exception ex) {
            toast("Something went wrong. Open failed... " + ex.getMessage());
        }
    }

    //This method will save the current file state to the assigned csv file!
    private boolean doSave(boolean forceChooseFile) {
        try {
            if (forceChooseFile || repo.getCurrentFile().isEmpty() ) {
                JFileChooser fc = new JFileChooser();
                if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return false;
                Path chosen = fc.getSelectedFile().toPath();
                String name = chosen.getFileName().toString();
                if(!name.toLowerCase().endsWith(".csv")){
                    chosen = chosen.resolveSibling(name + ".csv");
                }
                repo.setCurrentFile(chosen);
            }
            repo.replaceAll(heroFunctionalities.listHeroes());
            repo.saveToFile();
            dirty = false;
            updateTitle();
            toast("Saved successfully! " + repo.getCurrentFile().get().toAbsolutePath());
            return true;
        } catch (Exception ex) {
            toast("Save failed: " + ex.getMessage());
            return false;
        }
    }

    // when doExit is hitted, it will prompt user to either save unchanged portion
    // or save without saving changes.
    private void doExit() {
        if(dirty) {
            int choice = JOptionPane.showConfirmDialog(this,
                    "You have unsaved changes!!! Save before exiting?" ,
                    "Unsaved changes...",
                    JOptionPane.YES_NO_CANCEL_OPTION);
            if (choice == JOptionPane.YES_NO_CANCEL_OPTION) return;
            if(choice == JOptionPane.YES_OPTION) {
                if (!doSave(false)) return;
            }
        }
        dispose();
        System.exit(0);
    }


    // enhance the view on the table of the data organizing them when calling in usable
    // objects making them able to be used
    private Hero rowToHero(int viewRow) {
        int r = heroTable.convertRowIndexToModel(viewRow);
        return new Hero(
                String.valueOf(heroModel.getValueAt(r, 0)),
                String.valueOf(heroModel.getValueAt(r, 1)),
                Integer.parseInt(String.valueOf(heroModel.getValueAt(r, 2))),
                Integer.parseInt(String.valueOf(heroModel.getValueAt(r, 3))),
                Integer.parseInt(String.valueOf(heroModel.getValueAt(r, 4))),
                String.valueOf(heroModel.getValueAt(r, 5)),
                Double.parseDouble(String.valueOf(heroModel.getValueAt(r, 6)))
        );
    }

    // since we already know how many characters, numbers, or words might
    // hold an attribute, we will assign those on them such as ID which must be 3 digtis
    private static class HeroForm {
        private final JDialog dlg;
        private final JTextField tfId = new JTextField(4);
        private final JTextField tfName = new JTextField(22);
        private final JTextField tfHp = new JTextField(4);
        private final JTextField tfSpeed = new JTextField(2);
        private final JTextField tfUlt = new JTextField(5);
        private final JComboBox<String> cbRole =
                new JComboBox<>(new String[]{"DUELIST", "STRATEGIST", "VANGUARD"});
        private final JTextField tfWin = new JTextField(5);

        private Hero result = null;


        // Used when creating or updating a hero value
        HeroForm(Frame owner, Hero preset) {
            dlg = new JDialog(owner, (preset == null ? "Add Hero" : "Update Hero"), true);

            JPanel p = new JPanel(new GridBagLayout());
            GridBagConstraints gc = new GridBagConstraints();
            // adding some padding !
            gc.insets = new Insets(6, 8, 6, 8);
            gc.fill = GridBagConstraints.HORIZONTAL;
            // this part will be shown on the add hero or update input window
            int r = 0;
            addRow(p, gc, r++, "Hero Identity ID (3-digits):", tfId);
            addRow(p, gc, r++, "Hero Name: (3 words)", tfName);
            addRow(p, gc, r++, "Health Point: (250~900)", tfHp);
            addRow(p, gc, r++, "Movement Speed: (6~9)", tfSpeed);
            addRow(p, gc, r++, "Ultimate Damage: (300~9999)", tfUlt);
            addRow(p, gc, r++, "Hero Role:", cbRole);
            addRow(p, gc, ++r, "Win Rate:(0.00~100)", tfWin);

            JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            JButton ok = new JButton("OK"), cancel = new JButton("Cancel");
            buttonsPanel.add(ok); buttonsPanel.add(cancel);

            dlg.getContentPane().add(p, BorderLayout.CENTER);
            dlg.getContentPane().add(buttonsPanel, BorderLayout.SOUTH);
            dlg.pack();
            dlg.setLocationRelativeTo(owner);

            if (preset != null) {
                tfId.setText(preset.getIdentityHeroID());
                tfName.setText(preset.getHeroName());
                tfHp.setText(String.valueOf(preset.getHealthPoint()));
                tfSpeed.setText(String.valueOf(preset.getMovementSpeed()));
                tfUlt.setText(String.valueOf(preset.getUltDamage()));
                cbRole.setSelectedItem(preset.getHeroRole().toUpperCase());
                tfWin.setText(String.valueOf(preset.getWinRate()));
            }

            // will be validating the input and if something seems off will not
            // take those values into count.
            ok.addActionListener(e -> {
                try {
                    String id = tfId.getText().trim();
                    String name = tfName.getText().trim().replaceAll("\\s+", " ");
                    int hp = Integer.parseInt(tfHp.getText().trim());
                    int speed = Integer.parseInt(tfSpeed.getText().trim());
                    int ult = Integer.parseInt(tfUlt.getText().trim());
                    String roleRaw = String.valueOf(cbRole.getSelectedItem());
                    String role = HeroFunctionalities.HeroRoleFormat(roleRaw);

                    if(role == null) {
                        JOptionPane.showMessageDialog(dlg, "Role must be Duelist, Strategist, or Vanguard.");
                        return;
                    }
                    double wr = Double.parseDouble(tfWin.getText().trim());
                    // simple GUI-side validation (your service will re-validate too)
                    if (!id.matches("\\d{3}") || name.isEmpty()
                            || hp < 250 || hp > 900
                            || speed < 6 || speed > 9
                            || ult < 300 || ult > 9999
                            || wr < 0 || wr > 100) {
                        JOptionPane.showMessageDialog(dlg, "Please fix invalid entries.");
                        return;
                    }
                    result = new Hero(id, name, hp, speed, ult, role, wr);
                    dlg.dispose();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dlg, "Please fix invalid entries.");
                }
            });
            cancel.addActionListener(e -> dlg.dispose());
        }

        // this will organize the rows creating one of them.
        private static void addRow(JPanel p, GridBagConstraints gc, int row, String label, JComponent field) {
            gc.gridx = 0; gc.gridy = row; gc.weightx = 0;
            p.add(new JLabel(label), gc);
            gc.gridx = 1; gc.gridy = row; gc.weightx = 1;
            p.add(field, gc);
        }
        Hero showDialog() { dlg.setVisible(true); return result; }
    }
    // main to start the program
    public static void main(String[] args) {
    SwingUtilities.invokeLater(MainFrame::new);
    }
}
