package main;
import java.util.List;


//Interface to allow flexibility in the code for the GUI
public interface HeroRepository {
    boolean save(Hero hero);
    List<Hero> findAll();
    boolean update(Hero hero);
    boolean deleteById(String id);
    boolean existsById(String id);
}
