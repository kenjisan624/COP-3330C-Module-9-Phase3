package main;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;


//this will help managing csv and txt file to store and supporting
// correct handling such as save, findAll, replaceAll, ... and the other
public class FileHeroRepository implements HeroRepository {

    private Path currentFile;
    private final List<Hero> heroes = new ArrayList<>();

    @Override
    public boolean save(Hero hero) {
        deleteById(hero.getIdentityHeroID());
        heroes.add(hero);
        return true;
    }
    @Override
    public List<Hero> findAll() {
        return new ArrayList<>(heroes);
    }
    public void replaceAll(List<Hero> newHeroes) {
        heroes.clear();
        heroes.addAll(newHeroes);
    }
    @Override
    public boolean update(Hero hero) {
        deleteById(hero.getIdentityHeroID());
        heroes.add(hero);
        return true;
    }
    @Override
    public boolean deleteById(String id) {
        return heroes.removeIf(h -> h.getIdentityHeroID().equals(id));
    }
    @Override
    public boolean existsById(String id) {
        return heroes.stream().anyMatch(h -> h.getIdentityHeroID().equals(id));
    }
    public Optional<Path> getCurrentFile() {
        return Optional.ofNullable(currentFile);
    }
    public void setCurrentFile(Path file) {
        this.currentFile = file;
    }
    public void saveToFile() throws IOException {
        if (currentFile == null)
            throw new IllegalStateException("No file selected for saving");

        Path tmp = currentFile.resolveSibling(currentFile.getFileName() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
                for (Hero h : heroes) {
                    writer.write(h.toFileLine());
                    writer.newLine();
                }
            }

            Files.move(tmp, currentFile, StandardCopyOption.REPLACE_EXISTING);
        }
    }